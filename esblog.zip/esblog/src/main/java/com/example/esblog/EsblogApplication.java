package com.example.esblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsblogApplication {

    public static void main(String[] args) {
        SpringApplication.run(EsblogApplication.class, args);
    }

}

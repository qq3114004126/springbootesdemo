package com.example.esblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsblogApplicationTests {

    @Test
    void contextLoads() {
    }

}
